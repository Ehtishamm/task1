<?php
	$db = mysqli_connect("localhost","root","","user");
	if(!$db){
		echo "Database connect error".mysqli_error();
	}
	$phone = $_POST['phone'];
    $email = $_POST['email'];
	$username = $_POST['username'];
	$password = $_POST['password'];


	$insert = $db->query(UPDATE register SET username= '".$username."',email= '".$email."',phone= '".$phone."',password= '".$password."' WHERE 1");
	if($insert){
		echo json_encode($url);
	}