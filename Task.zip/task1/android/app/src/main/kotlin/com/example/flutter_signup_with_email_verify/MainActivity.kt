package com.example.flutter_signup_with_email_verify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
