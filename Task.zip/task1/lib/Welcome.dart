import 'package:flutter/material.dart';
import 'package:flutter_signup_with_email_verify/main.dart';
import 'package:flutter_signup_with_email_verify/profile.dart';

class Welcome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
      automaticallyImplyLeading: false,
      ),
      body: Container(
        child: Center(
          child: FlatButton(
            child: Text(
              "Profile",
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold
              ),
            ),
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context)=>ProfilePage(),),);
        },
          ),
        ),
      ),
    );
  }
}