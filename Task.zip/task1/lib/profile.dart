import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_signup_with_email_verify/Welcome.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:http/http.dart' as http;
import 'package:toast/toast.dart';

import 'Login.dart';
import 'crediantial.dart';



class Profile extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Profile Page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: ProfilePage(),
    );
  }
}

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePage createState() => _ProfilePage();
}

class _ProfilePage extends State<ProfilePage> {

  bool verifyButton = false;

  TextEditingController user = TextEditingController();
  TextEditingController pass = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController email = TextEditingController();

  String verifylink;
  Future signUp() async {
    if (user.text.isNotEmpty) {
      var response = await http.post(
          Uri.parse("http://127.0.0.1/task1/update.php"),
          body: {
            "username": user.text,
            "email"  : email.text,
            "phone"   : phone.text,
            "password": pass.text,
          }
      );
      var link = json.decode(response.body);

      if(link.body.isNotEmpty) {
        var data = json.decode(response.body);
        if (data == "Error") {
          showToast("Not Update");
        } else {
          showToast("Update");
          Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage(),),);
        }
      }

      //print(verifylink);

      showToast(
          "Thanks for registering with Flutter localhost. Please click this link to complete this registation",
          duration: 4,
          gravity: Toast.CENTER);
    } else {
      showToast("Enter Username and password first",
          duration: 3, gravity: Toast.TOP);
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile Page'),

      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Center(child: Text('Profile page',style: TextStyle(fontSize: 40,fontFamily: 'Nasalization'),),),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: user,
                decoration: InputDecoration(hintText: 'Username'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: email,
                decoration: InputDecoration(hintText: 'Email'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: phone,
                decoration: InputDecoration(hintText: 'Phone'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: pass,
                decoration: InputDecoration(hintText: 'Password'),
              ),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                MaterialButton(
                  color: Colors.purple,
                  child: Text(
                    'profile Update',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    setState(() {
                      signUp();
                      user.text;
                      pass.text;
                      phone.text;
                      email.text;
                    });
                  },
                ),


              ],
            ),

          ],
        ),
      ),
    );
  }

  void showToast(String msg, {int duration, int gravity}) {
    Toast.show(msg, context, duration: duration, gravity: gravity);
  }
}
