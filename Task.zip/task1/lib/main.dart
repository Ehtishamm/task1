import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_signup_with_email_verify/Welcome.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:http/http.dart' as http;
import 'package:toast/toast.dart';

import 'Login.dart';
import 'crediantial.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter signup with email verify',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Welcome(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  

  TextEditingController user = TextEditingController();
  TextEditingController pass = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController email = TextEditingController();

  Future signUp() async {
    if (user.text.isNotEmpty) {
      var response = await http.post(
          Uri.parse("http://127.0.0.1/task1/signup.php"),
          body: {
            "username": user.text,
             "email"  : email.text,
            "phone"   : phone.text,
            "password": pass.text,
          }
            );
      var link = json.decode(response.body);
      if(link.body.isNotEmpty) {
        var data = json.decode(response.body);
        if (data == "Error") {
          showToast("THis user aleady exist");
        } else {
          showToast("New user register ");
          Navigator.push(context, MaterialPageRoute(builder: (context)=>Welcome(),),);
        }
      }

      //print(verifylink);

      showToast(
          "Thanks for registering with Flutter localhost. Please click this link to complete this registation",
          duration: 4,
          gravity: Toast.CENTER);
    } else {
      showToast("Enter Username and password and phone and email first ",
          duration: 3, gravity: Toast.TOP);
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Localhost Xamp CRUD'),

      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Center(child: Text('SignUp',style: TextStyle(fontSize: 40,fontFamily: 'Nasalization'),),),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: user,
                decoration: InputDecoration(hintText: 'Username'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: email,
                decoration: InputDecoration(hintText: 'Email'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: phone,
                decoration: InputDecoration(hintText: 'Phone'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: pass,
                decoration: InputDecoration(hintText: 'Password'),
              ),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                MaterialButton(
                  color: Colors.purple,
                  child: Text(
                    'Sign Up',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    setState(() {
                      signUp();
                      user.text = "";
                      pass.text = "";
                      email.text = "";
                      phone.text = "";
                    });
                  },
                ),
                SizedBox(
                  width: 20,
                ),
                MaterialButton(
                  color: Colors.green,
                  child: Text(
                    'Login',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LoginPage(),
                      ),
                    );
                  },
                ),
              ],
            ),
            ],
        ),
      ),
    );
  }

  void showToast(String msg, {int duration, int gravity}) {
    Toast.show(msg, context, duration: duration, gravity: gravity);
  }
}
