<?php 
	$db = mysqli_connect("localhost","root","","user");
	if(!$db){
		echo "Database connect error".mysqli_error();
	}
	$phone = $_POST['phone'];
    $email = $_POST['email'];
	$username = $_POST['username'];
	$password = $_POST['password'];

	
	$insert = $db->query("INSERT INTO register(username,email,phone,password,token)VALUES('".$username."','".$email."','".$phone."','".$password."')");
	if($insert){
		echo json_encode($url);
	}